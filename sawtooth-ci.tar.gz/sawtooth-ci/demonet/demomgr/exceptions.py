class LrException(Exception):
    pass
