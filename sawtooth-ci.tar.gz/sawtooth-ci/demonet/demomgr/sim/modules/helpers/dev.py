import time
import sys

time.sleep(int(sys.argv[1]))
