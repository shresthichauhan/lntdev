export TERRAFORM_STATE_DIR=$(pwd)/../terraform
export PROJECT=
